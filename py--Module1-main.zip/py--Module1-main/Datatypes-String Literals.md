# Datatypes-Read and Print a String in Python

## 🎯 Aim
To write a Python program to read a string from the user and then print it.

## 🧠 Algorithm
1. Assign a variable named `men_stepped_on_the_moon`.
2. Use `input()` to read a string from the user and store it in the variable.
3. Print the value stored in the variable.

## 🧾 Program
~~~
men_stepped_on_the_moon=input()
print(men_stepped_on_the_moon)
~~~

## Output

#![438098795-4f908af4-3ede-436b-ab3a-ce1aa9a7adc4](https://github.com/user-attachments/assets/6d64a5fa-b1cd-43a4-b1a3-dfa255432343)
# Result
Thus,the Python program to read a string from the user and then print it is created successfully.
