# Datatypes-Character Literal in Python

## 🎯 Aim
To write a Python program that prints the characters `'T'` and `'a'` using character literals.

## 🧠 Algorithm
1. Print the character `'T'`.
2. Print the character `'a'`.

## 🧾 Program
~~~
a='T'
b='a'
print(a)
print(b)
~~~
## Output
![438092306-46c885d6-3cb6-4006-b3be-08d97d86236d](https://github.com/user-attachments/assets/546ea7c7-1df7-4f57-bf6c-fcd481c25ae2)

## Result
Thus,the Python program that prints the characters 'T' and 'a' using character literals is created successfully.
